
def discount(price):
    return int(price)*0.9