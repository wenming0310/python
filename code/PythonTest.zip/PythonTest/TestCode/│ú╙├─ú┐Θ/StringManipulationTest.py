'''
msg = "Monster truck rally. 4pm. Monday."
#print(msg.upper())  #字符串处理为大写

#msg1 = msg.upper(); #字符串处理为大写，后面加不加“;”分号都可以
#msg1 = msg.lower() #字符串处理为小写
#msg1 = msg.endswith(".jpg") #判断字符串是否以.jpg结尾
#msg1 = msg.startswith("<HTML>") #判断字符串是否以<HTML>为开头
#msg1 = msg.replace("tomorrow", "Tuesday");  #将字符串里面的tomorrow替换为Tuesday
#msg1 = msg.strip(); #去除头尾的空白后输出
msg1 = msg.find("truck");  #返回第一个找到的truck的第一个字符位置，没有返回-1

print(msg1)
'''
str = "Rock a by baby,\n\ton the tree top,\t\when the windblows\n\t\t\t the cradle will drop"
print(str)