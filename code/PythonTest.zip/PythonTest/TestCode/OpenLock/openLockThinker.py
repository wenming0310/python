from tkinter import *

app = Tk()
app.title("循环开锁程序")
app.geometry('300x100+200+100')

num_count = IntVar()
num_count.set(0)

labelDisplay = Label(app, text = 'When you are ready, click on the buttons!', height = 2)
labelDisplay.pack()

#textBoxDisplay = Text()
labelAllCountDisplay = Label(app, text = '总数')
labelAllCountDisplay.pack(side = 'left')
labelAllCountOutput = Label(app, textvariable = num_count)
labelAllCountOutput.pack(side = 'left')

labelTrueCountOutput = Label(app, textvariable = num_count)
labelTrueCountOutput.pack(side = 'left')
num_count.set(100)

app.mainloop()