import urllib.request
import time

def OpenLock(sn):
    url = "https://api.yeeuu.com/v2/device/" + str(sn) +"/open?key=superman"
    #"https://api.yeeuu.com/v2/device/00124b000f0b9ce0/open?key=superman"
    page = urllib.request.urlopen(url)
    text = page.read().decode("utf8")
    #print(text)
    where = text.find('''"success":''')
    result = where + 10
    #print(text[result:result + 4])
    if text[result:result + 4] == 'true':
        return 1
    else:
        return 0

#OpenLock('00124b000f0b9ce0') #tevin
#OpenLock('00124b000d2659c6')
print(OpenLock('00124b000f0b9ce0'))
